abstract class GeneralBank{
public abstract double getSavingsInteresRate();
public abstract double getFixefDepositInterestRate();
}
class ICICIBank extends GeneralBank{
public double getSavingsInteresRate(){
return 4;
}
public double getFixefDepositInterestRate(){
return 8.5;
}
}
class KotMBank extends GeneralBank{
public double getSavingsInteresRate(){
return 6;
}
public double getFixefDepositInterestRate(){
return 9;
}
}
class Pgm1{
public static void main(String args[]){
ICICIBank i=new ICICIBank();
KotMBank k=new KotMBank();
GeneralBank g=new KotMBank();
GeneralBank h=new ICICIBank();
System.out.println(i.getSavingsInteresRate());
System.out.println(i.getFixefDepositInterestRate());
System.out.println();
System.out.println(k.getSavingsInteresRate());
System.out.println(k.getFixefDepositInterestRate());
System.out.println();
System.out.println(g.getSavingsInteresRate());
System.out.println(g.getFixefDepositInterestRate());
System.out.println();
System.out.println(h.getSavingsInteresRate());
System.out.println(h.getFixefDepositInterestRate());
}
}