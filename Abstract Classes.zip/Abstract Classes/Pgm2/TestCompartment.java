import java.util.Random;
abstract class Compartment{
public abstract String notice();
}
class FirstClass extends Compartment{
@Override
public String notice(){
System.out.println("First class compartment");
return null;
}
}
class Ladies extends Compartment{
@Override
public String notice(){
System.out.println("Ladies compartment");
return null;
}
}
class General extends Compartment{
@Override
public String notice(){
System.out.println("General compartment");
return null;
}
}
class Luggage extends Compartment{
@Override
public String notice(){
System.out.println("Luggage compartment");
return null;
}
}
class TestCompartment{
public static void main(String args[]){
Compartment[] compartment=new Compartment[10];
Random rand=new Random();
for(int i=0;i<10;i++){
int randomnumber=rand.nextInt((4-1)+1);
if(randomnumber==1){
compartment[i]=new FirstClass();
}
else if(randomnumber==2){
compartment[i]=new Ladies();
}
else if(randomnumber==3){
compartment[i]=new General();
}
else if(randomnumber==4){
compartment[i]=new Luggage();
}
compartment[i].notice();
System.out.println();
}
}
}