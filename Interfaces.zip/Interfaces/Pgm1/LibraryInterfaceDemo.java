import java.lang.String;
interface LibraryUser{
public void registerAccount();
public void requestBook();
}
 class KidUsers implements LibraryUser{
int age;
String booktype;
KidUsers(int a,String b){
age=a;
booktype=b;
}
public void registerAccount(){
if(age<12){System.out.println("you have successfully regisered under a kids account");}
else{System.out.println("Sorry,Age must be less than 12 to register as a kid");}
}
public void requestBook(){
if(booktype.equals("Kids")){System.out.println("Book Issued successfully, please return the book within 10 days");}
else{System.out.println("Oops, you are allowed to take only kids books");}
}
}
 class AdultUser implements LibraryUser{
int age;
String booktype;
AdultUser(int a,String b){
age=a;
booktype=b;
}
public void registerAccount(){
if(age>12){System.out.println("You have successfully registered under an Adult Account");}
else{System.out.println("Sorry, Age must be greater than 12 to register as an adult");}
}
public void requestBook(){
if(booktype.equals("Fiction")){System.out.println("Book Issued successfully, please return the book within 7 days");}
else{System.out.println("Oops, you are allowed to take only adult fiction books");}
}
}
class LibraryInterfaceDemo{
public static void main(String args[]){
KidUsers k=new KidUsers(11,"Kids");
AdultUser a=new AdultUser(13,"Fiction");
k.registerAccount();
a.registerAccount();
k.requestBook();
a.requestBook();
}
}