package Program2.music.wind;
import Program2.music.Playable;
public class Sexaphone implements Playable{

	@Override
	public void play() {
		System.out.println("Sexaphone play");
	}

}
