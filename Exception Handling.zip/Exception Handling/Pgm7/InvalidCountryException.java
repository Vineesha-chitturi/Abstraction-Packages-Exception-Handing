class InvalidCountryException extends Exception{
public InvalidCountryException(){
System.out.println("User Outside India  cannot be registered");
}
}