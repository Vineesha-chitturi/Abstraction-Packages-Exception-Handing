class UserRegistration{
public void registerUser(String username,String userCountry) throws InvalidCountryException {
if(userCountry.equals("India")){System.out.println("User registration done successfully");}
else
throw new InvalidCountryException();
}
}
class Pgm7{
public static void main(String args[]){
try{
UserRegistration u=new UserRegistration();
u.registerUser(args[0],args[1]);
}
catch(InvalidCountryException e){
System.out.println(e);
}
}
}