class HighAgeException extends Exception{
public HighAgeException(){
System.out.println("Entered age is greater than 60");
}
}