class LessAgeException extends Exception{
public LessAgeException(){
System.out.println("Entered age is less than 18");
}
}