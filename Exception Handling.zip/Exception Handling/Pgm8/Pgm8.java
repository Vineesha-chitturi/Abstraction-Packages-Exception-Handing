class Pgm8{
public static void main(String args[]){
try{
String name=args[0];
int age=Integer.parseInt(args[1]);
if(age<18){
throw new LessAgeException();
}
else{System.out.println("entered age is greater than 18 and less than 60");}
if(age>60){
throw new HighAgeException();
}
}
catch(LessAgeException e){
System.out.println(e);
}
catch(HighAgeException e){
System.out.println(e);
}
}
}