import java.util.InputMismatchException;
class Pgm4 {
public static void main(String args[]){
try{
int n=args.length;
int sum=0;
int avg=0;
int arr[]=new int[5];
for(int i=0;i<n;i++){
arr[i]=Integer.parseInt(args[i]);
}
for(int i=0;i<n;i++){
sum=sum+arr[i];
}
avg=sum/n;
System.out.println("sum="+sum);
System.out.println("avg="+avg);
}
catch(ArithmeticException e){
System.out.println("ArithmeticException");
}
catch(NumberFormatException e){
System.out.println("NumberFormatException");
}
catch(ArrayIndexOutOfBoundsException e){
System.out.println("ArrayIndexOutOfBoundsException");
}
catch(InputMismatchException e){
System.out.println("InputMismatchException");
}
}
}