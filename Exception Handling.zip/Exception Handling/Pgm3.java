import java.util.Scanner;
import java.util.InputMismatchException;
class Pgm3{
public static void main(String args[]){
Scanner s=new Scanner(System.in);
System.out.println("Enter the number of elements in the array");
int n=s.nextInt();
int arr[]=new int[n];
System.out.println("Enter the elements in the array");
try{
for(int i=0;i<n;i++){arr[i]=s.nextInt();}
System.out.println("Enter the index of the array element you want to access");
int k=s.nextInt();
System.out.println(arr[k]);
System.out.println("The array element successfully accessed");
}
catch(ArrayIndexOutOfBoundsException e){
System.out.println("java.lang.ArrayIndexOutOfBoundsException");
}
catch(InputMismatchException e){
System.out.println("java.lang.InputMismatchException");
}
}
}