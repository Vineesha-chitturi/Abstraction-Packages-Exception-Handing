import java.util.Scanner;
import java.util.InputMismatchException;
class Pgm5{
public static void main(String args[]){
try{
Scanner s=new Scanner(System.in);
int a=s.nextInt();
int b=s.nextInt();
int c=a/b;
System.out.println(c);
}
catch(ArithmeticException e){
System.out.println("ArithmeticException");
}
catch(NumberFormatException e){
System.out.println("NumberFormatException");
}
catch(InputMismatchException e){
System.out.println("InputMismatchException");
}
}
}