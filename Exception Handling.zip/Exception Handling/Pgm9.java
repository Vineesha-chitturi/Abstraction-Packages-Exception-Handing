import java.util.Scanner;
class Pgm9{
public static void main(String args[]){
try{
Scanner s= new Scanner(System.in);
System.out.println("Enter the 2 numbers");
int a=s.nextInt();
int b=s.nextInt();
int c=a/b;
System.out.println("The quotient of "+a+"/"+b+"="+c);
}
catch(ArithmeticException e)
{System.out.println("DivideByZeroException caught");}
finally{
System.out.println("Inside finally block");
}
}
}