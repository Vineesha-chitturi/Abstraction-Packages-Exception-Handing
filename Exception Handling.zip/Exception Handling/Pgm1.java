class Pgm1{
public static void main(String args[]){
try{
int i=Integer.parseInt(args[0]);
System.out.println(i*i);
System.out.println("The work has been done successfully");
}
catch(NumberFormatException e){
System.out.println("Entered input is not a valid format for an integer.");
}
}
}