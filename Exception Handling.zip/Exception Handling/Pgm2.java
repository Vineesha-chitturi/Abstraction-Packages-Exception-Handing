import java.util.Scanner;
class Pgm2{
public static void main(String args[]){
try{
Scanner s=new Scanner(System.in);
System.out.println("Enter the number of elements in the array");
int n=s.nextInt();
int arr[]=new int[n];
System.out.println("Enter the elements in the array");
for(int i=0;i<n;i++){arr[i]=s.nextInt();}
System.out.println("Enter the index of the array element you want to access");
int k=s.nextInt();
System.out.println(arr[k]);
System.out.println("The array element successfully accessed");
}
catch(ArrayIndexOutOfBoundsException e){
System.out.println("java.lang.ArrayIndexOutOfBoundsException");
}
}
}