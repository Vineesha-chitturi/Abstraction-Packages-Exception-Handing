public class NegativeValuesException extends Exception{
public NegativeValuesException()
{
System.out.println("NegativeValuesException occured"); 
}
}
