public class ValuesOutOfRangeException extends Exception{public ValuesOutOfRangeException()
{
System.out.println("ValuesOutOfRangeException occured ");
}
}
